
# Two Faces of Nature: A Digital Comparative Study of Nature’s Past and Present States in Literature

**Researcher:** Eprene (Digital Humanities)  
**Date:** 2025-10-27

## 1. Abstract
This project compares literary representations of nature in two periods—**Romantic/Pre‑Industrial** and **Modern/Industrial**—to examine how textual depictions shift from **purity, harmony, and the sublime** to **pollution, alienation, and ecological loss**. Using computational text analysis (Voyant, AntConc, and optional Python workflows), the study quantifies and visualizes changes in **lexicon, sentiment, and thematic networks** around “Nature,” demonstrating how language encodes our changing ecological consciousness.

## 2. Background & Rationale
Romantic poets (Wordsworth, Coleridge, Shelley, Keats, Blake) sacralize nature as a moral and spiritual force. With industrial modernity, writers like T. S. Eliot, Hopkins, Muir, and Sinclair register **urban fogs, deforestation, and industrial filth**. This project situates literary change within **ecocriticism** and **environmental humanities**, mapping how metaphors move from **sublime communion** to **environmental crisis**.

## 3. Research Questions
1. How does the **affective vocabulary** (joy, awe, reverence vs. decay, waste, smog) differ across periods?  
2. Which **nature entities** (river, forest, bird, wind) change in **collocation** and **sentiment**?  
3. Can we trace a **decline in ecological reverence** via topic and network modeling?  
4. How do **figurative patterns** (sublime, pastoral) transform into **entropic/industrial imagery**?

## 4. Corpus
- **Corpus A (Romantic):** Wordsworth (*Tintern Abbey*), Coleridge (*Rime*), Shelley (*Ode to the West Wind*), Keats (*To Autumn*), Blake (*Auguries of Innocence*), Thoreau (*Walden*).  
- **Corpus B (Modern/Industrial):** Eliot (*The Waste Land*), Hopkins (*Binsey Poplars*), Muir (“The American Forests”), Sinclair (*The Jungle*).  
All selections are **public domain** excerpts assembled for analysis.

## 5. Methods
- **Exploratory Text Mining:** Voyant Tools (word frequency, distinctive terms, contexts/KWIC, collocation graphs).  
- **Comparative Concordance:** AntConc to compare target lemmas (e.g., river, wind, tree, fog, smoke, oil).  
- **Sentiment/Polarity (optional):** Python (NLTK/VADER) over lemmatized texts; compare distributions between corpora.  
- **Topic Modeling (optional):** Gensim/MALLET to find themes (e.g., “harvest/ripeness” vs. “waste/industry”).  
- **Network Visualization:** Co‑occurrence networks in Gephi to map conceptual neighborhoods around “nature.”

## 6. Analytical Plan
- Build **keyword lists** for purity vs. pollution (e.g., *sublime, bloom, song* vs. *fog, smoke, oil, tar*).  
- Compute **relative frequencies** and **log‑likelihood** differences across corpora.  
- Visualize **time‑sliced sentiment** and **entity-specific concordances** (e.g., “river” in Wordsworth vs. Eliot).  
- Annotate examples qualitatively to interpret computational trends.

## 7. Expected Outcomes
- A set of **visualizations** (term clouds, trends, networks) revealing a **linguistic shift** from ecstasy and reverence to crisis and contamination.  
- A **short paper** or poster summarizing computational findings with close readings.  
- A reusable **open corpus** for future DH courses.

## 8. Ethics & Copyright
All texts are in the **public domain**. The released corpus may be reused with attribution.

## 9. Timeline (suggested)
- **Week 1–2:** Finalize corpus & metadata; upload to Voyant/AntConc.  
- **Week 3–4:** Exploratory analytics (keywords, sentiment, collocations).  
- **Week 5:** Topic/network modeling; draft visualizations.  
- **Week 6:** Write report/poster; polish findings.

## 10. Tools
Voyant Tools, AntConc, Gephi/Cytoscape; optional Python (NLTK, spaCy, Gensim).

## 11. References (indicative)
- Jonathan Bate, *Romantic Ecology* (1991)  
- Greg Garrard, *Ecocriticism* (2nd ed.)  
- Timothy Morton, *Ecology Without Nature* (2007)

---

**Data Package**: See attached ZIP (CSV + TEI‑XML + per‑text TXT files).  
**How to use**: Upload the **texts** folder to Voyant, or load the **CSV** into your pipeline.
