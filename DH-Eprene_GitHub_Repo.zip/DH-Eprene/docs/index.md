# Nature: Poetry or Report? — DH · Eprene

See visuals in `/visuals/charts/` and datasets in `/data/`.
