# Nature: Poetry or Report? — DH - Eprene

**Creator:** Eprene  
**Build date:** 2025-10-27

This repository compares **Pre-Industrial poetic Nature** with **Post/Hyper-Industrial datafied Nature** using Digital Humanities methods.

## Structure
- `data/` — CSV/JSON/TEI datasets (fact-cards, 50-point comparisons, insights, manifests)
- `texts/` — TEI corpus (Romantic → Modern)
- `visuals/` — charts & infographics (Then ↔ Now)
- `images/` — curated Then/Now images (with manifest)
- `docs/` — methods, bibliography, site pages
- `code/` — notebooks/scripts (optional)

## Quick Start
- See `data/DATA_INVENTORY.csv` for all assets.
- Charts in `visuals/charts/` include timelines and the ratio plot you uploaded.
