# Timelines & Visuals

- **Cumulative Philosophical vs Material Events** — `visuals/charts/cumulative_events.png`  
- **Events by Century** — `visuals/charts/events_by_century.png`  
- **Motif × Stressor Heatmap** — `visuals/charts/motif_stressor_heatmap.png`  
- **Agency Analysis (Nature as Subject vs Object)** — `visuals/charts/agency_analysis.png`  

Use the notebook in `/code/DH_Eprene_reproducible.ipynb` to regenerate these.
