Nature Through Poetry — Analytical Insights (DH-Ready)
Date: 2025-10-27

Files:
1) nature_poetry_insights_summary.csv — Long-form, row-wise records with motif, poets, regions, THEN (poetic signal), NOW (present state), indicators and tags.
2) nature_poetry_insights_summary.jsonl — JSON Lines for NLP pipelines (spaCy, transformers, etc.).
3) nature_poetry_insights_summary.xml — TEI-XML for scholarly workflows.
4) nature_poetry_insights_heatmap.csv — Binary indicator matrix + 1–5 severity for heatmaps and clustering.

Suggested uses:
- Voyant/CATMA: ingest CSV; tag 'then' vs 'now' for concordance.
- Gephi: project heatmap CSV bipartite links (motif ↔ indicator).
- Python: parse JSONL for classification or prompt-based labeling.
- TEI-aware editors: validate and extend metadata (e.g., add poem IDs, stanza refs).

Notes:
- Indicators summarize widely reported statistics (FAO, GFW, WHO, WMO, IPBES, IUCN, WWF, UNEP). For precision, align with the most recent reports in your bibliography.
