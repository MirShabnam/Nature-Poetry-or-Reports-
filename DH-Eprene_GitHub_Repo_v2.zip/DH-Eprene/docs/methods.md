Methods: normalization → TEI/CSV → analysis (keywords, collocations, agency) → visualization → publication.
