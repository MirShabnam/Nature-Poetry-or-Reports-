Bibliography: FAO, GFW, WMO, WHO, IPBES, IUCN, WWF, peer-reviewed studies cited in data tables.
